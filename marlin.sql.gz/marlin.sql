-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Окт 16 2020 г., 05:50
-- Версия сервера: 5.7.26
-- Версия PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `marlin`
--

-- --------------------------------------------------------

--
-- Структура таблицы `staff`
--

CREATE TABLE `staff` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `position` varchar(100) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `banned` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `staff`
--

INSERT INTO `staff` (`id`, `name`, `position`, `twitter`, `img`, `banned`) VALUES
(1, 'Sunny A. (UI/UX Expert)', 'Lead Author', '@myplaneticket', 'img/demo/authors/sunny.png', NULL),
(2, 'Jos K. (ASP.NET Developer)', 'Partner &amp; Contributor', '@atlantez', 'img/demo/authors/josh.png', NULL),
(3, 'Jovanni L. (PHP Developer)', 'Partner &amp; Contributor', '@lodev09', 'img/demo/authors/jovanni.png', 1),
(4, 'Roberto R. (Rails Developer)', 'Partner &amp; Contributor', '@sildur', 'img/demo/authors/roberto.png', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `stafflist`
--

CREATE TABLE `stafflist` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(80) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `username` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `stafflist`
--

INSERT INTO `stafflist` (`id`, `name`, `surname`, `username`) VALUES
(1, 'Mark', 'Otto', '@mdo	'),
(2, 'Jacob', 'Thornton', '@fat	'),
(3, 'Larry', 'the Bird	', '@twitter	'),
(4, 'Larry the Bird	', 'Bird', '@twitter	');

-- --------------------------------------------------------

--
-- Структура таблицы `tel`
--

CREATE TABLE `tel` (
  `id` int(11) UNSIGNED NOT NULL,
  `phone` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tel`
--

INSERT INTO `tel` (`id`, `phone`) VALUES
(1, '89282922567'),
(2, '89298464388'),
(3, '89298464388');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `staff`
--
ALTER TABLE `staff`
  ADD UNIQUE KEY `id` (`id`);

--
-- Индексы таблицы `stafflist`
--
ALTER TABLE `stafflist`
  ADD UNIQUE KEY `id` (`id`);

--
-- Индексы таблицы `tel`
--
ALTER TABLE `tel`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `stafflist`
--
ALTER TABLE `stafflist`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `tel`
--
ALTER TABLE `tel`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
